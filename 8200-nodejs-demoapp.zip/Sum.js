exports.isSum = (number) => {
    return (number*2);
}